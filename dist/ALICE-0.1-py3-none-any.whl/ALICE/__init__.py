# this is workaround for changing the backend in pycharm - uncomment if using pycharm
import matplotlib
matplotlib.use('Agg')

# this is mostly for the jupyter notebook
import matplotlib.pyplot as plt
plt.rcParams['figure.dpi'] = 150
